const chai = require('chai');
const cHttp = require('chai-http');
const app = require('./../index');
//
chai.use(cHttp);
chai.should();
describe('The App', function(){
  describe('GET /getdocs', function(){
    it('it should get all documents', function(done){
      chai.request(app).get('/getdocs')
      .end(function(err, res){
        res.body.should.be.a('array');
      });
      done();
    })
  });
});
