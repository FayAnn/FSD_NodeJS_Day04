// const winston = require('winston');
// const path = require("path");
// const expressWinston = require('express-winston');

const path = require("path");
const { createLogger, transports ,format } = require('winston');
const logger = createLogger({
  level: 'error',
  format: format.combine(
    format.json(),
    format.timestamp()
),
  transports: [
    new transports.File({ filename: path.join(__dirname, './../logs/winston.log')})
  ]
});
//
module.exports = logger;

//
// const ew = expressWinston.errorLogger({
//   transports: [
//     new winston.transports.File({filename: path.join(__dirname, './../logs/winston.log')})
//   ],
//   expressFormat: true
// });
//
// const ew = expressWinston.logger({
//   transports: [
//     new winston.transports.File({filename: path.join(__dirname, './../logs/winston.log')})
//   ],
//   meta: false,
//   expressFormat: true, ignoreRoute: function (req, res) { return false; }
// });
//
//module.exports = ew;
